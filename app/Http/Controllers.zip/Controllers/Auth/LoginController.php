<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\Models\Setting;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    // protected $redirectTo = '/home';

    public function redirectTo(){
        $user = auth()->user();

        if ($user->hasRole('admin')) {
            return route('home'); // Admin dashboard
        } elseif ($user->hasRole('superadmin')) {
            return route('home');
        } elseif ($user->hasRole('user')) {
            return route('user');
        }

        return route('user'); // fallback
    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
        $this->middleware('auth')->only('logout');
    }

       public function showLoginForm()
    {
        $settings = Setting::query()->pluck("value", "setting_name")->toArray();
        return view('auth.login', compact('settings'));
    }
}
