<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">

<head>
    <meta charset="utf-8">
    <title>Vitour - Travel & Tour Booking HTML Template</title>

    <meta name="author" content="themesflat.com">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link rel="stylesheet" href="app/css/app.css">
    <link rel="stylesheet" href="app/css/bootstrap-select.min.css">
    <link rel="stylesheet" href="app/css/map.min.css">

    <!-- Favicon and Touch Icons  -->
    <link rel="shortcut icon" href="assets/images/favico.png">
    <link rel="apple-touch-icon-precomposed" href="assets/images/favico.png">

</head>

<body class="body header-fixed ">

    <div class="preload preload-container">
        <svg class="pl" width="240" height="240" viewBox="0 0 240 240">
            <circle class="pl__ring pl__ring--a" cx="120" cy="120" r="105" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 660" stroke-dashoffset="-330" stroke-linecap="round"></circle>
            <circle class="pl__ring pl__ring--b" cx="120" cy="120" r="35" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 220" stroke-dashoffset="-110" stroke-linecap="round"></circle>
            <circle class="pl__ring pl__ring--c" cx="85" cy="120" r="70" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 440" stroke-linecap="round"></circle>
            <circle class="pl__ring pl__ring--d" cx="155" cy="120" r="70" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 440" stroke-linecap="round"></circle>
        </svg>
    </div>

    <!-- /preload -->

    <div id="wrapper">

        <div id="pagee" class="clearfix">

            <div class="sidebar-dashboard">
                <div class="db-logo">
                    <a href="index.html"><img src="assets/images/favico.png" alt="Logo"><span>Vitour</span></a>
                </div>
                <div class="db-menu">
                    <ul>
                        <li class="active">
                            <a href="dashboard.html">
                                <i class="icon-Vector-9"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <li>
                            <a href="my-booking.html">
                                <i class="icon-Layer-2"></i>
                                <span>My Booking</span>
                            </a>
                        </li>
                        <li>
                            <a href="my-listing.html">
                                <i class="icon-Group-81"></i>
                                <span>My Listing</span>
                            </a>
                        </li>
                        <li>
                            <a href="add-tour.html">
                                <i class="icon-Group-91"></i>
                                <span>Add Tour</span>
                            </a>
                        </li>
                        <li>
                            <a href="my-favorite.html">
                                <i class="icon-Vector-10"></i>
                                <span>My Favorites</span>
                            </a>
                        </li>
                        <li>
                            <a href="my-profile.html">
                                <i class="icon-profile-user-1"></i>
                                <span>My Profile</span>
                            </a>
                        </li>
                        <li>
                            <a href="login.html">
                                <i class="icon-turn-off-1"></i>
                                <span>Logout</span>
                            </a>
                        </li>

                    </ul>


                </div>

            </div>

            <div class="has-dashboard">
                <!-- Main Header -->
                <header class="main-header flex">
                    <!-- Header Lower -->
                    <div id="header">
                        <div class="header-dashboard">
                            <div class="tf-container full">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="inner-container flex justify-space align-center">
                                            <!-- Logo Box -->
                                            <div class="header-search flex-three">
                                                <div class="icon-bars">
                                                    <i class="icon-Vector3"></i>
                                                </div>
                                                <form action="/" class="search-dashboard">
                                                    <i class="icon-Vector5"></i>
                                                    <input type="search" placeholder="Search tours">
                                                </form>

                                            </div>
                                            <div class="nav-outer flex align-center">
                                                <!-- Main Menu -->
                                                <nav class="main-menu show navbar-expand-md">
                                                    <div class="navbar-collapse collapse clearfix"
                                                        id="navbarSupportedContent">
                                                        <ul class="navigation clearfix">
                                                            <li class="dropdown2">
                                                                <a href="#">Home</a>
                                                                <ul>
                                                                    <li><a href="index.html">Home Page 01</a></li>
                                                                    <li><a href="home2.html">Home Page 02</a></li>
                                                                    <li><a href="home3.html">Home Page 03</a></li>
                                                                    <li><a href="home4.html">Home Page 04</a></li>
                                                                    <li><a href="home5.html">Home Page 05</a></li>
                                                                </ul>
                                                            </li>
                                                            <li class="dropdown2">
                                                                <a href="#">Tour</a>
                                                                <ul>
                                                                    <li><a href="archieve-tour.html">Archieve tour</a>

                                                                    </li>
                                                                    <li><a href="tour-package-v2.html">Tour left
                                                                            sidebar</a>

                                                                    </li>
                                                                    <li><a href="tour-package-v4.html">Tour package </a>

                                                                    </li>
                                                                    <li><a href="tour-single.html">Tour Single </a>

                                                                    </li>
                                                                </ul>
                                                            </li>
                                                            <li class="dropdown2"><a href="#">Destination</a>
                                                                <ul>
                                                                    <li><a href="tour-destination-v1.html">Destination
                                                                            V1</a></li>
                                                                    <li><a href="tour-destination-v2.html">Destination
                                                                            V2</a></li>
                                                                    <li><a href="tour-destination-v3.html">Destination
                                                                            V3</a></li>
                                                                    <li><a href="single-destination.html">Destination
                                                                            Single</a></li>
                                                                </ul>
                                                            </li>
                                                            <li class="dropdown2 "><a href="#">Blog</a>
                                                                <ul>
                                                                    <li><a href="blog.html">Blog</a></li>
                                                                    <li><a href="blog-details.html">Blog Detail</a></li>
                                                                </ul>
                                                            </li>

                                                            <li class="dropdown2 "><a href="#">Pages</a>
                                                                <ul>
                                                                    <li><a href="about-us.html">About Us</a></li>
                                                                    <li><a href="team.html">Team member</a></li>
                                                                    <li><a href="gallery.html">Gallery</a></li>
                                                                    <li><a href="terms-condition.html">Terms &
                                                                            Condition</a></li>
                                                                    <li><a href="help-center.html">Help center</a></li>
                                                                </ul>
                                                            </li>
                                                            <li class="dropdown2 current"><a href="#">Dashboard</a>
                                                                <ul>
                                                                    <li class="current"><a
                                                                            href="dashboard.html">Dashboard</a>
                                                                    </li>
                                                                    <li><a href="my-booking.html">My booking</a></li>
                                                                    <li><a href="my-listing.html">My Listing</a></li>
                                                                    <li><a href="add-tour.html">Add Tour</a></li>
                                                                    <li><a href="my-favorite.html">My Favorites</a></li>
                                                                    <li><a href="my-profile.html">My profile</a></li>
                                                                </ul>
                                                            </li>
                                                            <li><a href="contact-us.html">Contact</a></li>
                                                        </ul>
                                                    </div>
                                                </nav>
                                                <!-- Main Menu End-->
                                            </div>
                                            <div class="header-account flex align-center">

                                                <div class="dropdown notification">
                                                    <a class="icon-notification" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <i class="icon-notification-1"></i>
                                                    </a>
                                                    <ul class="dropdown-menu">
                                                      <li>
                                                        <div class="message-item  flex-three">
                                                            <div class="image">
                                                                <i class="icon-26"></i>
                                                            </div>
                                                            <div>
                                                                <div class="body-title">Discount available</div>
                                                                <div class="text-tiny">Morbi sapien massa, ultricies at rhoncus at, ullamcorper nec diam</div>
                                                            </div>
                                                        </div>
                                                      </li>
                                                      <li>
                                                        <div class="message-item  flex-three">
                                                            <div class="image">
                                                                <i class="icon-26"></i>
                                                            </div>
                                                            <div>
                                                                <div class="body-title">Discount available</div>
                                                                <div class="text-tiny">Morbi sapien massa, ultricies at rhoncus at, ullamcorper nec diam</div>
                                                            </div>
                                                        </div>
                                                      </li>
                                                      <li>
                                                        <div class="message-item  flex-three">
                                                            <div class="image">
                                                                <i class="icon-26"></i>
                                                            </div>
                                                            <div>
                                                                <div class="body-title">Discount available</div>
                                                                <div class="text-tiny">Morbi sapien massa, ultricies at rhoncus at, ullamcorper nec diam</div>
                                                            </div>
                                                        </div>
                                                      </li>

                                                    </ul>
                                                </div>
                                                <div class="dropdown account">
                                                    <a type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <img src="./assets/images/page/avata.jpg" alt="image">
                                                    </a>
                                                    <ul class="dropdown-menu">
                                                      <li><a  href="#">Account</a></li>
                                                      <li><a  href="#">Setting</a></li>
                                                      <li><a  href="#">Support</a></li>
                                                      <li><a  href="login.html">Logout</a></li>
                                                    </ul>
                                                </div>
                                                <div class="mobile-nav-toggler mobile-button">
                                                    <i class="icon-bar"></i>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- End Header Lower -->


                    <!-- Mobile Menu  -->
                    <div class="close-btn"><span class="icon flaticon-cancel-1"></span></div>
                    <div class="mobile-menu">
                        <div class="menu-backdrop"></div>
                        <nav class="menu-box">
                            <div class="nav-logo"><a href="index.html">
                                    <img src="assets/images/logo2.png" alt=""></a></div>
                            <div class="bottom-canvas">
                                <div class="menu-outer">
                                </div>
                            </div>
                        </nav>
                    </div>
                    <!-- End Mobile Menu -->

                </header>
                <!-- End Main Header -->
                <main id="main">
                    <section class="profile-dashboard">
                        <div class="inner-header mb-40">
                            <h3 class="title">Dashboard</h3>
                            <p class="des">There are many variations of passages of Lorem Ipsum</p>
                        </div>
                        <div class="counter-grid-dashboard mb-70">
                            <div class="counter-dashboard flex-three tf-countto">
                                <div class="icon flex-five">
                                    <i class="icon-earnings-1"></i>
                                </div>
                                <div class="content">
                                    <span>Total Earning</span>
                                    <div class="number-counter money" data-to="43216" data-speed="2000"
                                        data-waypoint-active="yes">43216</div>
                                </div>
                            </div>
                            <div class="counter-dashboard flex-three tf-countto">
                                <div class="icon flex-five">
                                    <i class="icon-heart-1"></i>
                                </div>
                                <div class="content">
                                    <span>My Wishlist</span>
                                    <div class="number-counter plus" data-to="2351" data-speed="2000"
                                        data-waypoint-active="yes">2351</div>
                                </div>
                            </div>
                            <div class="counter-dashboard flex-three tf-countto">
                                <div class="icon flex-five">
                                    <i class="icon-Group-1000003085"></i>
                                </div>
                                <div class="content">
                                    <span>Total Listing</span>
                                    <div class="number-counter" data-to="43216" data-speed="2000"
                                        data-waypoint-active="yes">43216</div>
                                </div>
                            </div>
                            <div class="counter-dashboard flex-three tf-countto">
                                <div class="icon flex-five">
                                    <i class="icon-feedback"></i>
                                </div>
                                <div class="content">
                                    <span>Total Listing</span>
                                    <div class="number-counter plus" data-to="2351" data-speed="2000"
                                        data-waypoint-active="yes">2351</div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xxl-8 col-xl-12">
                                <div class="page-insight">
                                    <!-- chart -->
                                    <div class="wg-box">
                                        <div class="flex-two">
                                            <h5>Total page view</h5>
                                            <div class="group-select">
                                                <div class="nice-select" tabindex="0">
                                                    <span class="current">This Week</span>
                                                    <ul class="list">
                                                        <li data-value class="option selected">This Week</li>
                                                        <li data-value="Last day" class="option">Last Day</li>
                                                        <li data-value="Last Week" class="option">Last Week</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="line-chart-1"></div>
                                    </div>
                                    <!-- /chart -->
                                </div>
                            </div>
                            <div class="col-xxl-4 col-xl-12">
                                <div class="tfcl-card dashboard-message mb-25">
                                    <h4 class="title mb-30">What,s New?</h4>
                                    <ul class="message">
                                        <li class="flex-three">
                                            <div class="icon">
                                                <i class="icon-Group4"></i>
                                            </div>
                                            <p>Congratulation Your <span class="text-main">23</span> Listing has been
                                                approved Today</p>
                                        </li>
                                        <li class="flex-three">
                                            <div class="icon">
                                                <i class="icon-Vector-131"></i>
                                            </div>
                                            <p>Someone is saved your listing</p>
                                        </li>
                                        <li class="flex-three">
                                            <div class="icon">
                                                <div class="icon-Vector-141"></div>
                                            </div>
                                            <p>You have unread <span class="text-main">21</span> Message</p>
                                        </li>
                                        <li class="flex-three">
                                            <div class="icon">
                                                <i class="icon-Vector-131"></i>
                                            </div>
                                            <p>Congratulation Your <span class="text-main">22</span> Listing has
                                                been</p>
                                        </li>
                                        <li class="flex-three">
                                            <div class="icon">
                                                <i class="icon-Vector-131"></i>
                                            </div>
                                            <p>Mehedii Added Favorites Your listing “Mercedez Benz 2.3”</p>
                                        </li>
                                        <li class="flex-three">
                                            <div class="icon">
                                                <i class="icon-Vector-141"></i>
                                            </div>
                                            <p>You have unread <span class="text-main">21</span> Message</p>
                                        </li>
                                        <li class="flex-three">
                                            <div class="icon">
                                                <i class="icon-Vector-131"></i>
                                            </div>
                                            <p>Congratulation Your <span class="text-main">22</span> Listing has been
                                            </p>
                                        </li>
                                    </ul>
                                </div>
                                <div class="tfcl-card dashboard-reviews">
                                    <h4 class="title mb-30">Recent Reviews</h4>
                                    <ul>
                                        <li class="comment-by-user flex-three">
                                            <div class="group-author">
                                                <img src="./assets/images/avata/avt-review.jpg" alt="image">
                                            </div>
                                            <div class="content">
                                                <div class="group-name flex-one">
                                                    <div class="review-name">Rohan De Spond</div>
                                                    <div class="rating-wrap">
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                    </div>
                                                </div>
                                                <p>Lorem ipsum dolor sit amet, con covered many vulputate ves
                                                </p>
                                            </div>
                                        </li>
                                        <li class="comment-by-user flex-three">
                                            <div class="group-author">
                                                <img src="./assets/images/avata/avt-review2.jpg" alt="image">
                                            </div>
                                            <div class="content">
                                                <div class="group-name flex-one">
                                                    <div class="review-name">Mehedii. Has</div>
                                                    <div class="rating-wrap">
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                    </div>
                                                </div>
                                                <p>Lorem ipsum dolor sit amet, con covered many vulputate ves
                                                </p>
                                            </div>
                                        </li>
                                        <li class="comment-by-user flex-three">
                                            <div class="group-author">
                                                <img src="./assets/images/avata/avt-review.jpg" alt="image">
                                            </div>
                                            <div class="content">
                                                <div class="group-name flex-one">
                                                    <div class="review-name">Rohan De Spond</div>
                                                    <div class="rating-wrap">
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                    </div>
                                                </div>
                                                <p>Lorem ipsum dolor sit amet, con covered many vulputate ves
                                                </p>
                                            </div>
                                        </li>
                                        <li class="comment-by-user flex-three">
                                            <div class="group-author">
                                                <img src="./assets/images/avata/avt-review3.jpg" alt="image">
                                            </div>
                                            <div class="content">
                                                <div class="group-name flex-one">
                                                    <div class="review-name">Mehedii. Has</div>
                                                    <div class="rating-wrap">
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                        <i class="icon-Star"></i>
                                                    </div>
                                                </div>
                                                <p>Lorem ipsum dolor sit amet, con covered many vulputate ves
                                                </p>
                                            </div>
                                        </li>

                                    </ul>

                                </div>

                            </div>
                        </div>

                    </section>

                </main>

                <footer class="footer footer-dashboard">
                    <div class="tf-container full">
                        <div class="row">
                            <div class="col-xl-6">
                                <p class="text-white">Made with ❤️ by Themesflat. - Powered by Theme</p>
                            </div>
                            <div class="col-xl-6">
                                <ul class="menu-footer flex-six">
                                    <li>
                                        <a href="#">Privacy & Policy</a>
                                    </li>
                                    <li>
                                        <a href="#">Licensing</a>
                                    </li>
                                    <li>
                                        <a href="#">Instruction</a>
                                    </li>
                                </ul>

                            </div>
                        </div>

                    </div>
                </footer>

                <!-- Bottom -->
            </div>

        </div>
        <!-- /#page -->
    </div>

    <!-- Modal Popup Bid -->

    <a id="scroll-top" class="button-go"></a>

    <!-- Modal search-->
    <div class="modal search-mobie fade" id="exampleModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                <div class="modal-body">
                    <form action="/" class="search-form-mobie">
                        <div class="search">
                            <i class="icon-circle2017"></i>
                            <input type="search" placeholder="Search Travel" class="search-input" autocomplete="off">
                            <button type="button">Search</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>


    <!-- Javascript -->
    <script src="app/js/jquery.min.js"></script>
    <script src="app/js/jquery.nice-select.min.js"></script>
    <script src="app/js/bootstrap.min.js"></script>
    <script src="app/js/bootstrap-select.min.js"></script>
    <script src="app/js/tinymce/tinymce.min.js"></script>
    <script src="app/js/tinymce/tinymce-custom.js"></script>
    <script src="app/js/swiper-bundle.min.js"></script>
    <script src="app/js/swiper.js"></script>
    <script src="app/js/plugin.js"></script>
    <script src="app/js/map.min.js"></script>
    <script src="app/js/map.js"></script>
    <script src="app/js/countto.js"></script>
    <script src="app/js/apexcharts.js"></script>
    <script src="app/js/line-chart.js"></script>
    <script src="app/js/shortcodes.js"></script>
    <script src="app/js/main.js"></script>

</body>

</html>
