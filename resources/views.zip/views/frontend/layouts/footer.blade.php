     <footer class="footer footer-style1">
                <div class="tf-container">
                    <div class="footer-main">
                        <div class="footer-logo">
                            <div class="logo-footer">
                               <a href="{{route('frontend.index')}}"> <img src="{{asset("uploads/" . $settings["SETTING_SITE_LOGO"])}}" alt=""></a>
                            </div>
                            {{-- <p class="des-footer">The world’s first and largest digital market
                                for crypto collectibles and non-fungible
                            </p> --}}
                            {{-- <ul class="footer-info">
                                <li class="flex-three">
                                    <i class="icon-noun-mail-5780740-1"></i>
                                    <p>{!! $settings["CONTACT_EMAIL"] !!}</p>
                                </li>
                                <li class="flex-three">
                                    <i class="icon-Group-9"></i>
                                    <p>{!! $settings["CONTACT_PHONE"] !!}</p>
                                </li>
                                <li class="flex-three">
                                    <i class="icon-Layer-19"></i>
                                    <p>{{ $settings["CONTACT_ADDRESS"] }}</p>
                                </li>
                            </ul> --}}

                        </div>

                              <div class="footer-logo">
                            {{-- <div class="logo-footer">
                               <a href="{{route('frontend.index')}}"> <img src="{{asset("uploads/" . $settings["SETTING_SITE_LOGO"])}}" alt=""></a>
                            </div> --}}
                            {{-- <p class="des-footer">The world’s first and largest digital market
                                for crypto collectibles and non-fungible
                            </p> --}}
                            <ul class="footer-info">
                                <li class="flex-three">
                                    <i class="icon-noun-mail-5780740-1"></i>
                                    <p>{!! $settings["CONTACT_EMAIL"] !!}</p>
                                </li>
                                <li class="flex-three">
                                    <i class="icon-Group-9"></i>
                                    <p>{!! $settings["CONTACT_PHONE"] !!}</p>
                                </li>
                                <li class="flex-three">
                                    <i class="icon-Layer-19"></i>
                                    <p>{{ $settings["CONTACT_ADDRESS"] }}</p>
                                </li>
                            </ul>

                        </div>
                        <div class="footer-service">
                            <h5 class="title">Services Req</h5>

                            <ul class="footer-menu">
                                <li>
                                    <a href="{{route('frontendAbout')}}">About Us</a>
                                </li>
                                {{-- <li>
                                    <a href="gallery.html">Gallery</a>
                                </li> --}}
                                <li>
                                    <a href="{{route('frontendTeamMember')}}">Our Team</a>
                                </li>
                                <li>
                                    <a href="{{route('frontendBlog')}}">Blog </a>
                                </li>
                                <li>
                                    <a href="{{route('frontendContact')}}">Contact</a>
                                </li>
                            </ul>

                        </div>
                        {{-- <div class="footer-gallery">
                            <h5 class="title">Gallery</h5>

                            <div class="gallery-img">
                                <a href="./assets/images/gallery/gl1.jpg" data-fancybox="gallery">
                                    <img src="./assets/images/gallery/gl1.jpg" alt="image gallery">
                                </a>
                                <a href="./assets/images/gallery/gl2.jpg" data-fancybox="gallery">
                                    <img src="./assets/images/gallery/gl2.jpg" alt="image gallery">
                                </a>
                                <a href="./assets/images/gallery/gl3.jpg" data-fancybox="gallery">
                                    <img src="./assets/images/gallery/gl3.jpg" alt="image gallery">
                                </a>
                                <a href="./assets/images/gallery/gl4.jpg" data-fancybox="gallery">
                                    <img src="./assets/images/gallery/gl4.jpg" alt="image gallery">
                                </a>
                                <a href="./assets/images/gallery/gl5.jpg" data-fancybox="gallery">
                                    <img src="./assets/images/gallery/gl5.jpg" alt="image gallery">
                                </a>
                                <a href="./assets/images/gallery/gl6.jpg" data-fancybox="gallery">
                                    <img src="./assets/images/gallery/gl6.jpg" alt="image gallery">
                                </a>
                            </div>

                        </div> --}}
                        <div class="footer-newsletter">
                            <h5 class="title">Newsletter</h5>
                            <form action="/" id="footer-form">
                                <div class="input-wrap flex-three">
                                    <input type="email" placeholder="Enter Email Adress">
                                    <button type="submit"><i class="icon-paper-plane"></i></button>
                                </div>
                                <div class="check-form flex-three">
                                    <i class="icon-Vector-121"></i>
                                    <p>I agree to all your terms and policies</p>
                                </div>

                            </form>
                            {{-- <ul class="social-ft flex-three">
                                <li>
                                    <a href="#">
                                        <i class="icon-icon-2"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-x"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-8"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-2"></i>
                                    </a>
                                </li>
                            </ul> --}}

                        </div>
                    </div>

                    <div class="row footer-bottom">
                        <div class="col-md-6">
                            <p class="copy-right">
                            Copyright © <span id="year"></span> by <a href="#" class="text-main">Falcon Dreams.</a> All Rights Reserved
                            </p>
                        </div>
                        <div class="col-md-6">
                            <ul class="social flex-six">
                                <li>
                                    <a href="{{ $settings["SETTING_SOCIAL_FACEBOOK"] }}">
                                        <i class="icon-icon-2"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="{{ $settings["SETTING_SOCIAL_TWITTER"] }}">
                                        <i class="icon-x"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="{{ $settings["SETTING_SOCIAL_YOUTUBE"] }}">
                                        <i class="fab fa-youtube"></i>

                                    </a>
                                </li>
                                <li>
                                    <a href="{{ $settings["SETTING_SOCIAL_INSTAGRAM"] }}">
                                       <i class="fab fa-instagram"></i>

                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </footer>
<script>
  // বর্তমান সাল বসানো
  document.getElementById("year").textContent = new Date().getFullYear();
</script>
